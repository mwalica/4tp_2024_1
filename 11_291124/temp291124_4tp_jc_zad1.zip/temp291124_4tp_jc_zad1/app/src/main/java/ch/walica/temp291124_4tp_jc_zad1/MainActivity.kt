package ch.walica.temp291124_4tp_jc_zad1

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.sp
import ch.walica.temp291124_4tp_jc_zad1.ui.theme.Blue
import ch.walica.temp291124_4tp_jc_zad1.ui.theme.Green
import ch.walica.temp291124_4tp_jc_zad1.ui.theme.Orange
import ch.walica.temp291124_4tp_jc_zad1.ui.theme.Red
import ch.walica.temp291124_4tp_jc_zad1.ui.theme.Temp291124_4tp_jc_zad1Theme
import ch.walica.temp291124_4tp_jc_zad1.ui.theme.Yellow

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Temp291124_4tp_jc_zad1Theme {
                MainScreen(modifier = Modifier.fillMaxSize())
            }
        }
    }
}


@Composable
fun MainScreen(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().weight(1f)
        ) {
            Box(
                modifier = Modifier.fillMaxHeight().weight(1f).background(Green),
                contentAlignment = Alignment.BottomCenter
            ) {
                Text(text = "Hello")
            }
            Box(
                modifier = Modifier.fillMaxHeight().weight(1f).background(Blue),
                contentAlignment = Alignment.Center
            ) {
                Text(text = "Hello", color = Color.Red)
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth().weight(2f)
        ) {
            Box(
                modifier = Modifier.fillMaxHeight().weight(1f).background(Yellow),
            ) {
                Text(text = "Hello", style = TextStyle(
                    color = Blue,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                ))
            }
            Box(
                modifier = Modifier.fillMaxHeight().weight(1f).background(Orange),
                contentAlignment = Alignment.CenterEnd
            ) {
                Text(text = "Hello", style = TextStyle(
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                ))
            }
            Box(
                modifier = Modifier.fillMaxHeight().weight(1f).background(Green)
            ) {
                Text(text = "Hello", style = TextStyle(
                    color = Color.White.copy(alpha = 0.7f),
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                ))
            }
        }
    }
}


@Preview(showBackground = true)
@Composable
fun MainScreenPreview() {
    Temp291124_4tp_jc_zad1Theme {
        MainScreen()
    }
}