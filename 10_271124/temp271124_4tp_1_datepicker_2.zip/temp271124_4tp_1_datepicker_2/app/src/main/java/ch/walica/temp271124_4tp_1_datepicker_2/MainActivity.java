package ch.walica.temp271124_4tp_1_datepicker_2;

import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.android.material.datepicker.MaterialPickerOnPositiveButtonClickListener;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        tvResult = findViewById(R.id.tvResult);

        MaterialDatePicker<Long> datePicker = MaterialDatePicker.Builder.datePicker()
                .setTitleText("Wybierz datę")
                .setSelection(MaterialDatePicker.todayInUtcMilliseconds())
                .build();

        tvResult.setOnClickListener(view -> {
            if(getSupportFragmentManager().findFragmentByTag("date_picker") == null) {
                datePicker.show(getSupportFragmentManager(), "date_picker");
                datePicker.addOnPositiveButtonClickListener(selection -> {
                    LocalDateTime localDateTime = LocalDateTime.ofInstant(Instant.ofEpochMilli(selection), ZoneId.of("Europe/Warsaw"));
                    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("d MMMM yyyy", Locale.forLanguageTag("pl"));
                    tvResult.setText(localDateTime.format(dtf));
                });
            }

        });
    }
}