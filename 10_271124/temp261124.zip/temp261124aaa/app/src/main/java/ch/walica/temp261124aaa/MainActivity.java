package ch.walica.temp261124aaa;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.datepicker.MaterialDatePicker;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    TextView tvResult1, tvResult2, tvResult3, tvResult4, tvResult5, tvResult6;
    Button btnDate1, btnDate2, btnYear, btnMonth, btnDay, btnHour, btnMinute, btnSecond;
    LocalDateTime date1;
    LocalDateTime date2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        tvResult1 = findViewById(R.id.tvResult1);
        tvResult2 = findViewById(R.id.tvResult2);
        tvResult3 = findViewById(R.id.tvResult3);
        tvResult4 = findViewById(R.id.tvResult4);
        tvResult5 = findViewById(R.id.tvResult5);
        tvResult6 = findViewById(R.id.tvResult6);
        btnDate1 = findViewById(R.id.btnDate1);
        btnDate2 = findViewById(R.id.btnDate2);
        btnYear = findViewById(R.id.btnYear);
        btnMonth = findViewById(R.id.btnMonth);
        btnDay = findViewById(R.id.btnDay);
        btnHour = findViewById(R.id.btnHour);
        btnMinute = findViewById(R.id.btnMinute);
        btnSecond = findViewById(R.id.btnSecond);

        btnYear.setOnClickListener(this);
        btnMonth.setOnClickListener(this);
        btnDay.setOnClickListener(this);
        btnHour.setOnClickListener(this);
        btnMinute.setOnClickListener(this);
        btnSecond.setOnClickListener(this);

        MaterialDatePicker<Long> datePicker1 = MaterialDatePicker.Builder.datePicker()
                .setTitleText("Wybierz datę")
                .setSelection(MaterialDatePicker.todayInUtcMilliseconds())
                .build();

        MaterialDatePicker<Long> datePicker2 = MaterialDatePicker.Builder.datePicker()
                .setTitleText("Wybierz datę")
                .setSelection(MaterialDatePicker.todayInUtcMilliseconds())
                .build();

        btnDate1.setOnClickListener(view -> {
            resetResult();
            datePicker1.show(getSupportFragmentManager(), "data_picker");
            datePicker1.addOnPositiveButtonClickListener(selection -> {
                date1 = LocalDateTime.ofInstant(Instant.ofEpochMilli(selection), ZoneId.of("UTC"));
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d MMMM yyyy");
                btnDate1.setText(date1.format(formatter));
            });
        });

        btnDate2.setOnClickListener(view -> {
            resetResult();
            datePicker2.show(getSupportFragmentManager(), "data_picker");
            datePicker2.addOnPositiveButtonClickListener(selection -> {
                date2 = LocalDateTime.ofInstant(Instant.ofEpochMilli(selection), ZoneId.of("UTC"));
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d MMMM yyyy");
                btnDate2.setText(date2.format(formatter));
            });
        });


    }

    @Override
    public void onClick(View v) {
        if (date1 != null && date2 != null) {
            long years = ChronoUnit.YEARS.between(date1, date2);
            long month = ChronoUnit.MONTHS.between(date1, date2);
            long day = ChronoUnit.DAYS.between(date1, date2);
            long hour = ChronoUnit.HOURS.between(date1, date2);
            long minute = ChronoUnit.MINUTES.between(date1, date2);
            long second = ChronoUnit.SECONDS.between(date1, date2);

            if (v.getId() == R.id.btnYear) {
                tvResult1.setText(Math.abs(years) + " lat");
            } else if (v.getId() == R.id.btnMonth) {
                tvResult2.setText(Math.abs(month) + " miesięcy");
            } else if (v.getId() == R.id.btnDay) {
                tvResult3.setText(Math.abs(day) + " dni");
            } else if (v.getId() == R.id.btnHour) {
                tvResult4.setText(Math.abs(hour) + " godzin");
            } else if (v.getId() == R.id.btnMinute) {
                tvResult5.setText(Math.abs(minute) + " minut");
            } else if (v.getId() == R.id.btnSecond) {
                tvResult6.setText(Math.abs(second) + " sekund");
            }
        } else {
            Toast.makeText(this, "Proszę wybrać zakres dat", Toast.LENGTH_SHORT).show();
        }

    }

    private void resetResult() {
        tvResult1.setText("");
        tvResult2.setText("");
        tvResult3.setText("");
        tvResult4.setText("");
        tvResult5.setText("");
        tvResult6.setText("");
    }
}