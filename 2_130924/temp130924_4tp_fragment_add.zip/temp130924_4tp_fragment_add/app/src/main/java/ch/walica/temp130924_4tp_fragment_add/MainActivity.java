package ch.walica.temp130924_4tp_fragment_add;

import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private Button btnToggle;
    private boolean isFragment = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        btnToggle = findViewById(R.id.btnToggle);

        btnToggle.setOnClickListener(view -> {
            if(!isFragment) {
                getSupportFragmentManager().beginTransaction().add(R.id.fragmentContainerView, new HomeFragment()).commit();
                btnToggle.setText("Usuń");
                isFragment = true;
            } else {
                getSupportFragmentManager().beginTransaction().remove(getSupportFragmentManager().findFragmentById(R.id.fragmentContainerView)).commit();
                btnToggle.setText("Dodaj");
                isFragment = false;
            }
        });



    }
}