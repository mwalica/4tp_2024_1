package ch.walica.temp61124_4tp_1_handler;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    TextView tvResult1, tvResult2;
    Button btnStop;
    Random random = new Random();
    Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        tvResult1 = findViewById(R.id.tvResul1);
        tvResult2 = findViewById(R.id.tvResul2);
        btnStop = findViewById(R.id.btnStop);

        Runnable runnable1 = new Runnable() {
            @Override
            public void run() {
                tvResult1.setText("To jest tekst, który pojawi się po 2 sekundach");
            }
        };

        Runnable runnable2 = new Runnable() {
            @Override
            public void run() {
                tvResult2.append("hello ");
                tvResult1.setTextColor(Color.rgb(random.nextInt(256), random.nextInt(256), random.nextInt(256)));
                handler.postDelayed(this, 1000);
            }
        };

        runnable2.run();

        handler.postDelayed(runnable1, 5000);

        btnStop.setOnClickListener(view -> {
            handler.removeCallbacks(runnable2);
        });
    }
}