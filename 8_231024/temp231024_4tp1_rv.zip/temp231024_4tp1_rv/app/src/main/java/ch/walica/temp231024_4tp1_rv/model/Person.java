package ch.walica.temp231024_4tp1_rv.model;

import java.util.Random;

public class Person {
    private String name;
    private int age;

    public Person(String name) {
        this.name = name;
        this.age = new Random().nextInt(80) + 18;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }
}
