package ch.walica.temp231024_4tp1_rv;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

import ch.walica.temp231024_4tp1_rv.adapter.PersonAdapter;
import ch.walica.temp231024_4tp1_rv.model.Person;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private FloatingActionButton floatingActionButton;
    private List<Person> persons = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        persons.add(new Person("Karol"));
        persons.add(new Person("Adam"));
        persons.add(new Person("Gustaw"));
        persons.add(new Person("Jan"));

        recyclerView = findViewById(R.id.recyclerView);
        floatingActionButton = findViewById(R.id.floatingActionButton);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        PersonAdapter adapter = new PersonAdapter(persons);
        recyclerView.setAdapter(adapter);

        floatingActionButton.setOnClickListener(v -> {
            View view = LayoutInflater.from(this).inflate(R.layout.edit_text_alert, null);
            EditText etName = view.findViewById(R.id.etName);

            new MaterialAlertDialogBuilder(this)
                    .setTitle("Dodaj osobę")
                    .setView(view)
                    .setPositiveButton("Dodaj", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            String name = etName.getText().toString().trim();
                            if (!name.isEmpty()) {
                                persons.add(new Person(name));
                                adapter.notifyDataSetChanged();
                            }

                        }
                    })
                    .setNegativeButton("Anuluj", null)
                    .show();

        });

    }
}