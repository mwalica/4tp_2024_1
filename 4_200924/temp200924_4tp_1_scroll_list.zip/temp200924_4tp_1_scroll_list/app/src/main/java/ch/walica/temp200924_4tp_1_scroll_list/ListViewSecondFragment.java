package ch.walica.temp200924_4tp_1_scroll_list;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import ch.walica.temp200924_4tp_1_scroll_list.model.Person;


public class ListViewSecondFragment extends Fragment {

    private ListView listView2;
    private String[] names = {"Jan", "Konrad", "Leon", "Gustaw", "Jan", "Konrad", "Leon", "Gustaw", "Jan", "Konrad", "Leon", "Gustaw"};
    private Person[] persons = {
            new Person("Karol"),
            new Person("Adam"),
            new Person("Karol"),
            new Person("Adam"),
            new Person("Karol"),
            new Person("Adam"),
            new Person("Karol"),
            new Person("Adam"),
            new Person("Karol"),
            new Person("Adam"),
            new Person("Karol"),
            new Person("Adam"),
    };
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_list_view_second, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        listView2 = view.findViewById(R.id.listView2);

//        ArrayAdapter<String> adapter1 = new ArrayAdapter<>(requireContext(), android.R.layout.simple_list_item_1, names);
//        ArrayAdapter<String> adapter1 = new ArrayAdapter<>(requireContext(), R.layout.name_item_1, R.id.tvName, names);
        ArrayAdapter<Person> adapter1 = new ArrayAdapter<>(requireContext(), R.layout.name_item_2, persons);
        listView2.setAdapter(adapter1);

        listView2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(requireContext(), "Kliknęte: " + persons[i].getName(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}