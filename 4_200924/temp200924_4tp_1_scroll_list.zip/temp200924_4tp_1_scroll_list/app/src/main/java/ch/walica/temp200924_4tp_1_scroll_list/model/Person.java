package ch.walica.temp200924_4tp_1_scroll_list.model;

import androidx.annotation.NonNull;

import java.util.Random;

public class Person {

    private String name;
    private int age;

    public Person(String name) {
        this.name = name;
        this.age = new Random().nextInt(80) + 18;
    }

    public String getName() {
        return name;
    }

    @NonNull
    @Override
    public String toString() {
        return name + " " + age;
    }
}
